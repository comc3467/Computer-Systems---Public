#include <stdio.h>
#include "cs1300bmp.h"
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include "Filter.h"

using namespace std;

#include "rdtsc.h"

//
// Forward declare the functions
//
Filter * readFilter(string filename);
double applyFilter(Filter *filter, cs1300bmp *input, cs1300bmp *output);

int
main(int argc, char **argv)
{

  if ( argc < 2) {
    fprintf(stderr,"Usage: %s filter inputfile1 inputfile2 .... \n", argv[0]);
  }

  //
  // Convert to C++ strings to simplify manipulation
  //
  string filtername = argv[1];

  //
  // remove any ".filter" in the filtername
  //
  string filterOutputName = filtername;
  string::size_type loc = filterOutputName.find(".filter");
  if (loc != string::npos) {
    //
    // Remove the ".filter" name, which should occur on all the provided filters
    //
    filterOutputName = filtername.substr(0, loc);
  }

  Filter *filter = readFilter(filtername);

  double sum = 0.0;
  int samples = 0;

  for (int inNum = 2; inNum < argc; inNum++) {
    string inputFilename = argv[inNum];
    string outputFilename = "filtered-" + filterOutputName + "-" + inputFilename;
    struct cs1300bmp *input = new struct cs1300bmp;
    struct cs1300bmp *output = new struct cs1300bmp;
    int ok = cs1300bmp_readfile( (char *) inputFilename.c_str(), input);

    if ( ok ) {
      double sample = applyFilter(filter, input, output);
      sum += sample;
      samples++;
      cs1300bmp_writefile((char *) outputFilename.c_str(), output);
    }
    delete input;
    delete output;
  }
  fprintf(stdout, "Average cycles per sample is %f\n", sum / samples);

}

class Filter *
readFilter(string filename)
{
  ifstream input(filename.c_str());

  if ( ! input.bad() ) {
    int size = 0;
    input >> size;
    Filter *filter = new Filter(size);
    int div;
    input >> div;
    filter -> setDivisor(div);
    for (int i=0; i < size; i++) {
      for (int j=0; j < size; j++) {
	int value;
	input >> value;
	filter -> set(i,j,value);
      }
    }
    return filter;
  } else {
    cerr << "Bad input in readFilter:" << filename << endl;
    exit(-1);
  }
}


double
applyFilter(class Filter *filter, cs1300bmp *input, cs1300bmp *output)
{

  long long cycStart, cycStop;

  cycStart = rdtscll();
    const short int in_height = input->height - 1;
    const short int in_width = input->width - 1; //this way, we only call the input->height or input->weight once
    output->width = in_width +1;
    output->height = in_height + 1;
    
    short int filterArray[3][3]; //sets up a quick lil double array of filters so that it's easier to access later
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            filterArray[i][j] = filter->get(i,j);
        }
    }
    const short int filterSize = filter->getSize(); //only calls filter->getSize() once
    const short int filterDivisor = filter->getDivisor(); //only calls filter->getDivisor() once
    int plane0temp0, plane0temp1, plane0temp2, plane0temp3, plane1temp0, plane1temp1, plane1temp2, plane1temp3, plane2temp0, plane2temp1, plane2temp2, plane2temp3;
    int row; //starts with row, not plane, since we've unrolled the plane loop entirely; need *3 accumulators
    for(row = 1; row < in_height - 1; row += 2){ //increment by two, need *2 accumulators
        int col;
        for(col = 1; col < in_width - 1; col += 2){ //increment by another two, need *2 accumulators
            plane0temp0 = 0;
            plane0temp1 = 0;
            plane0temp2 = 0;
            plane0temp3 = 0;
            plane1temp0 = 0;
            plane1temp1 = 0;
            plane1temp2 = 0;
            plane1temp3 = 0;
            plane2temp0 = 0;
            plane2temp1 = 0;
            plane2temp2 = 0;
            plane2temp3 = 0; //3*2*2 = 12, so we have 12 accumulators, four for each plane
            
            for(int i = 0; i < filterSize; i++){ //loop through the filter COLUMNS NESTED IN ROWS FOR SHORTER STEPS
                for(int j = 0; j < filterSize; j++){ //loop through the filter ; we could unroll this more, but then we'd have even moreee acc
                    int mult = filterArray[i][j]; //we basically are then working with 12 accumulators, so 12 positions (4 on each plane), @ i,j
                    plane0temp0 += input->color[0][row+i-1][col+j-1] * mult;
                    plane1temp0 += input->color[1][row+i-1][col+j-1] * mult;
                    plane2temp0 += input->color[2][row+i-1][col+j-1] * mult;
                    plane0temp1 += input->color[0][row+i-1][col+j] * mult;
                    plane1temp1 += input->color[1][row+i-1][col+j] * mult;
                    plane2temp1 += input->color[2][row+i-1][col+j] * mult;
                    plane0temp2 += input->color[0][row+i][col+j-1] * mult;
                    plane1temp2 += input->color[1][row+i][col+j-1] * mult;
                    plane2temp2 += input->color[2][row+i][col+j-1] * mult;
                    plane0temp3 += input->color[0][row+i][col+j] * mult;
                    plane1temp3 += input->color[1][row+i][col+j] * mult;
                    plane2temp3 += input->color[2][row+i][col+j] * mult; //*multi saving us time so that the filterArray[i][j] only accessed once
                }
            }
            if(filterDivisor != 0){
                plane0temp0 /= filterDivisor;
                plane0temp1 /= filterDivisor;
                plane0temp2 /= filterDivisor;
                plane0temp3 /= filterDivisor;
                plane1temp0 /= filterDivisor;
                plane1temp1 /= filterDivisor;
                plane1temp2 /= filterDivisor;
                plane1temp3 /= filterDivisor;
                plane2temp0 /= filterDivisor;
                plane2temp1 /= filterDivisor;
                plane2temp2 /= filterDivisor;
                plane2temp3 /= filterDivisor;
            }
            
            plane0temp0 = plane0temp0 < 0 ? 0 : plane0temp0 > 255 ? 255 : plane0temp0;
            plane1temp0 = plane1temp0 < 0 ? 0 : plane1temp0 > 255 ? 255 : plane1temp0;
            plane2temp0 = plane2temp0 < 0 ? 0 : plane2temp0 > 255 ? 255 : plane2temp0;
            plane0temp1 = plane0temp1 < 0 ? 0 : plane0temp1 > 255 ? 255 : plane0temp1;
            plane1temp1 = plane1temp1 < 0 ? 0 : plane1temp1 > 255 ? 255 : plane1temp1;
            plane2temp1 = plane2temp1 < 0 ? 0 : plane2temp1 > 255 ? 255 : plane2temp1;
            plane0temp2 = plane0temp2 < 0 ? 0 : plane0temp2 > 255 ? 255 : plane0temp2;
            plane1temp2 = plane1temp2 < 0 ? 0 : plane1temp2 > 255 ? 255 : plane1temp2;
            plane2temp2 = plane2temp2 < 0 ? 0 : plane2temp2 > 255 ? 255 : plane2temp2;
            plane0temp3 = plane0temp3 < 0 ? 0 : plane0temp3 > 255 ? 255 : plane0temp3;
            plane1temp3 = plane1temp3 < 0 ? 0 : plane1temp3 > 255 ? 255 : plane1temp3;
            plane2temp3 = plane2temp3 < 0 ? 0 : plane2temp3 > 255 ? 255 : plane2temp3; //i.g if,else statements that change each value to in range
            
            output -> color[0][row][col] = plane0temp0;
            output -> color[1][row][col] = plane1temp0;
            output -> color[2][row][col] = plane2temp0;
            output -> color[0][row][col+1] = plane0temp1;
            output -> color[1][row][col+1] = plane1temp1;
            output -> color[2][row][col+1] = plane2temp1;
            output -> color[0][row+1][col] = plane0temp2;
            output -> color[1][row+1][col] = plane1temp2;
            output -> color[2][row+1][col] = plane2temp2;
            output -> color[0][row+1][col+1] = plane0temp3;
            output -> color[1][row+1][col+1] = plane1temp3;
            output -> color[2][row+1][col+1] = plane2temp3; //applies these to output triple array
              
        }
        for(; col < in_width; col++){ //finishing up the col loop, since there should still be some left over if it's an odd number
            plane0temp0 = 0;
            plane1temp0 = 0;
            plane2temp0 = 0; //only need 6 accumulators
            plane0temp1 = 0;
            plane1temp1 = 0;
            plane2temp1 = 0;
            for(int i = 0; i < filterSize; i++){
                for(int j = 0; j < filterSize; j++){
                    int mult = filterArray[i][j];
                    plane0temp0 += input->color[0][row+i-1][col+j-1] * mult;
                    plane1temp0 += input->color[1][row+i-1][col+j-1] * mult;
                    plane2temp0 += input->color[2][row+i-1][col+j-1] * mult;
                    plane0temp1 += input->color[0][row+i][col+j-1] * mult;
                    plane1temp1 += input->color[1][row+i][col+j-1] * mult;
                    plane2temp1 += input->color[2][row+i][col+j-1] * mult;
                }
            }
            if(filterDivisor != 0){
                plane0temp0 /= filterDivisor;
                plane1temp0 /= filterDivisor;
                plane2temp0 /= filterDivisor;
                plane0temp1 /= filterDivisor;
                plane1temp1 /= filterDivisor;
                plane2temp1 /= filterDivisor;
            }
            
            plane0temp0 = plane0temp0 < 0 ? 0 : plane0temp0 > 255 ? 255 : plane0temp0;
            plane1temp0 = plane1temp0 < 0 ? 0 : plane1temp0 > 255 ? 255 : plane1temp0;
            plane2temp0 = plane2temp0 < 0 ? 0 : plane2temp0 > 255 ? 255 : plane2temp0;
            plane0temp1 = plane0temp1 < 0 ? 0 : plane0temp1 > 255 ? 255 : plane0temp1;
            plane1temp1 = plane1temp1 < 0 ? 0 : plane1temp1 > 255 ? 255 : plane1temp1;
            plane2temp1 = plane2temp1 < 0 ? 0 : plane2temp1 > 255 ? 255 : plane2temp1;

            output -> color[0][row][col] = plane0temp0;
            output -> color[1][row][col] = plane1temp0;
            output -> color[2][row][col] = plane2temp0;
            output -> color[0][row+1][col] = plane0temp1;
            output -> color[1][row+1][col] = plane1temp1;
            output -> color[2][row+1][col] = plane2temp1;
        }
    }
    for(; row < in_height; row++){//inc 1
        int col;
        for(col = 1; col < in_width; col++){ //inc 1 , so 1 col and 1 row, so 3*1*1 accumulators
            plane0temp0 = 0;
            plane1temp0 = 0;
            plane2temp0 = 0;
            for(int i = 0; i < filterSize; i++){
                for(int j = 0; j < filterSize; j++){
                    int mult = filterArray[i][j];
                    plane0temp0 += input->color[0][row+i-1][col+j-1] * mult;
                    plane1temp0 += input->color[1][row+i-1][col+j-1] * mult;
                    plane2temp0 += input->color[2][row+i-1][col+j-1] * mult;
                }
            }
            if(filterDivisor != 0){
                plane0temp0 /= filterDivisor;
                plane1temp0 /= filterDivisor;
                plane2temp0 /= filterDivisor;
            }

            plane0temp0 = plane0temp0 < 0 ? 0 : plane0temp0 > 255 ? 255 : plane0temp0;
            plane1temp0 = plane1temp0 < 0 ? 0 : plane1temp0 > 255 ? 255 : plane1temp0;
            plane2temp0 = plane2temp0 < 0 ? 0 : plane2temp0 > 255 ? 255 : plane2temp0;

            output -> color[0][row][col] = plane0temp0;
            output -> color[1][row][col] = plane1temp0;
            output -> color[2][row][col] = plane2temp0;
        }
    }
    

  cycStop = rdtscll();
  double diff = cycStop - cycStart;
  double diffPerPixel = diff / (output -> width * output -> height);
  fprintf(stderr, "Took %f cycles to process, or %f cycles per pixel\n",
	  diff, diff / (output -> width * output -> height));
  return diffPerPixel;
}


